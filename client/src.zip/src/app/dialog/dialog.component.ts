import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { MatDialogModule } from '@angular/material/dialog'; // Импортируем MatDialogModule
import { CommonModule } from '@angular/common'; // Для директив *ngIf и *ngFor
import { RouterModule } from '@angular/router'; // Для routerLink

@Component({
  selector: 'app-dialog',
  standalone: true, // Указываем, что это standalone-компонент
  imports: [MatDialogModule, CommonModule, RouterModule], // Добавляем необходимые модули
  template: `
    <h2 mat-dialog-title>{{ data.title }}</h2>
    <mat-dialog-content>
      <p>{{ data.content }}</p>

      <div *ngIf="data.sections?.length">
        <div class="modal__accordion" *ngFor="let section of data.sections">
          <button class="modal__accordion-title" (click)="toggleSection(section)">
            {{ section.title }}
          </button>
          <ul class="modal__accordion-content" [class.active]="section.isOpen">
            <li class="modal__accordion-content-item" *ngFor="let item of section.items">
              <div class="modal-content__link">{{ item.name }}</div>
              <div class="modal-content__link-container">
                <a class="modal-content__link-download" [href]="item.dwg" download>Скачать DWG</a>
                <a class="modal-content__link-download" [href]="item.pdf" download>Скачать PDF</a>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </mat-dialog-content>
    <mat-dialog-actions>
      <button mat-button (click)="onClose()">Закрыть</button>
    </mat-dialog-actions>
  `,
  styleUrls: ['./dialog.component.scss'],
})
export class DialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: {
      title: string;
      content: string;
      sections?: {
        title: string;
        isOpen?: boolean;
        items: { name: string; dwg: string; pdf: string }[];
      }[];
    },
    private dialogRef: MatDialogRef<DialogComponent>
  ) {}

  onClose() {
    this.dialogRef.close();
  }

  toggleSection(section: any) {
    section.isOpen = !section.isOpen;
  }
}
